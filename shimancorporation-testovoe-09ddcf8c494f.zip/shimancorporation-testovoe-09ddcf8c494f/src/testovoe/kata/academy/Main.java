package testovoe.kata.academy;

import testovoe.kata.academy.calculator.ArabicCalculator;
import testovoe.kata.academy.calculator.Calculator;
import testovoe.kata.academy.calculator.RomanCalculator;
import testovoe.kata.academy.exception.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // maybe we will implement some additional calculators in the future
        List<Calculator> availableCalculators = List.of(
                new ArabicCalculator(),
                new RomanCalculator()
        );

        try {
            System.out.println("Enter you equation:");
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(System.in));
            String equation = reader.readLine();


            boolean calculatorFound = false;
            // search for the first calculator which can execute the provided equation
            for (Calculator calculator : availableCalculators) {
                if (!calculatorFound && calculator.validateAndInitialize(equation)) {
                    System.out.println(calculator.calculate());
                    calculatorFound = true;
                }
            }

            if (!calculatorFound) {
                System.out.println("Failed to find a suitable calculator");
            }
        } catch (IOException e) {
            System.out.printf("Failed to read data from console. Exception = %s", e.getMessage());
        } catch (InvalidOperatorException e) {
            System.out.println("Provided operator is invalid");
        } catch (InvalidResultOfCalculationException e) {
            System.out.println("The result of calculation is invalid");
        } catch (NumberTooBigException e) {
            System.out.println("The provided number is too big. It must be less or equal to 10");
        } catch (NumberTooSmallException e) {
            System.out.println("The provided number is too small. It must be greater or equal to 1");
        }
    }
}