package testovoe.kata.academy.exception;

public class InvalidOperatorException extends RuntimeException {
}
