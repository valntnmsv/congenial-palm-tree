package testovoe.kata.academy.exception;

public class InvalidResultOfCalculationException extends RuntimeException {
}
