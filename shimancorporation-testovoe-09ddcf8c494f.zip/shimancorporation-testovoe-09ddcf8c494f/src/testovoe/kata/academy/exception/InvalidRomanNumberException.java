package testovoe.kata.academy.exception;

public class InvalidRomanNumberException extends RuntimeException {
}
