package testovoe.kata.academy.exception;

public class NumberTooBigException extends RuntimeException {
}
