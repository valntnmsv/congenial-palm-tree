package testovoe.kata.academy.exception;

public class NumberTooSmallException extends RuntimeException {
}
